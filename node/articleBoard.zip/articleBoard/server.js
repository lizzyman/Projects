/**
 * Created by Admin on 2017-05-16.
 */
const express = require('express');
const fs = require('fs');
const ejs = require('ejs');
const bodyParser = require('body-parser');

const app = express();

app.use('/download', express.static(__dirname + '/app/upload'));

app.use(bodyParser.urlencoded({extended: false}));

// form data를 받아오기 위해서 반드시 필요
app.use(bodyParser.json());

// module.exports 한 경우
app.use(require('./app/routes/index'));

app.listen(3000, function () {
  console.log('Server running at http://localhost:3000');
});

