import { ArticleBoardPage } from './app.po';

describe('article-board App', function() {
  let page: ArticleBoardPage;

  beforeEach(() => {
    page = new ArticleBoardPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
