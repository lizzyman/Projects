/**
 * Created by Admin on 2017-05-17.
 */
import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { ArticleComponent } from './article/article.component';
import {DetailComponet} from "./article/detail.component";
import {WriteComponent} from "./article/write.component";
import {ModifyComponent} from "./article/modify.component";
import {SigninComponent} from "./user/signin.component";
import {SignupComponent} from "./user/signup.component";

export const ROUTES:Routes = [
  {path:'', component: ArticleComponent},
  {path:'article/:id', component: DetailComponet},
  {path:'write', component: WriteComponent},
  {path:'modify/:id', component: ModifyComponent},
  {path:'user/signin', component: SigninComponent},
  {path:'user/signup', component: SignupComponent}
];

export const AppRoutingModule:ModuleWithProviders = RouterModule.forRoot(ROUTES);

