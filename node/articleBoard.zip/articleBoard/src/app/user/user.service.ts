/**
 * Created by Admin on 2017-05-17.
 */
import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import {User} from "./user";

@Injectable()
export class UserService {
  // 생성자에 private을 붙이면 멤버 변수로써 활용되어짐
  constructor(private http:Http) { }

  getOneUser(user:User):Observable<any> {
    const header = new Headers();
    header.append("Content-Type", "application/x-www-form-urlencoded");

    return this.http.post('http://localhost:3000/user/signin', `id=${user.id}&password=${user.password}`, {headers: header})
      .map(response => <any> response.json());
  }

  insertOneUser(user:User):Observable<boolean> {
    //console.log(user.id + "****" + user.password);
    const header = new Headers();
    header.append("Content-Type", "application/x-www-form-urlencoded");

    return this.http.post('http://localhost:3000/user/signup', `id=${user.id}&password=${user.password}&name=${user.name}`, {headers: header})
      .map(response => <boolean> response.json().result);
  }
}
