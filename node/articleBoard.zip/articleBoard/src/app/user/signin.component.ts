/**
 * Created by Admin on 2017-05-18.
 */
import {Component} from '@angular/core';
import {UserService} from './user.service';
import {Router} from "@angular/router";
import {UserConstant} from "./user.constant";

@Component({
  selector: 'signin',
  templateUrl: './signin.component.html'
})
export class SigninComponent {

  constructor(private userService:UserService, private router:Router) {}

  loginUser(loginForm) {
    this.userService.getOneUser(loginForm.form.value)
      .subscribe(response => {
        if (response.error) {
          alert(response.error);
        }
        else if (response.result) {
          // 상수에 받아온 user 정보를 넣어준다.
          UserConstant.user = response.user;
          this.router.navigate(['']);
        }
        else {
          alert("Wrong ID or Password!");
        }
      });
  }
}
