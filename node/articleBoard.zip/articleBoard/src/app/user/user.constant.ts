import {User} from "./user";

export class UserConstant {
  // static을 사용하면 angular 전역에서 가져다가 사용 가능
  // session 역할 : User의 정보를 받아오면(=login 했을 경우), 이곳에 저장
  public static user: User = {
    _id: '',
    id: '',
    name: '',
    password: ''
  };
}
