/**
 * Created by Admin on 2017-05-18.
 */
import {Component} from '@angular/core';
import {UserService} from './user.service';
import {Router} from "@angular/router";

@Component({
  selector: 'signup',
  templateUrl: './signup.component.html'
})
export class SignupComponent {

  constructor(private userService:UserService, private router:Router) {}

  signupUser(signupForm) {
    this.userService.insertOneUser(signupForm.form.value)
      .subscribe(response => {
        if (response) {
          this.router.navigate(['user/signin']);
        }
      });
  }
}

