/**
 * Created by Admin on 2017-05-18.
 */
export class User {
  _id: string;
  id: string;
  password: string;
  name: string;
}
