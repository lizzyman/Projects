/**
 * Created by Admin on 2017-05-17.
 */
import { Component } from '@angular/core';
import {Article} from "./article";
import {ArticleServcie} from "./article.service";

@Component({
  selector: 'article-list',
  templateUrl: '../article/article.component.html'
})
export class ArticleComponent {
  articles:Article[];

  // 생성자에 ArticleService를 주입
  constructor(private articleService:ArticleServcie) {}

  ngOnInit() {
    this.articleService.getAllArticles()
      .subscribe(articles => this.articles = articles);
  }
}
