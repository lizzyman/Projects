/**
 * Created by Admin on 2017-05-17.
 */
export class Article {
  _id:string;
  subject:string;
  content:string;
  writer:string;
  readCount:number;
  originalname:string;
  filename:string;
}
