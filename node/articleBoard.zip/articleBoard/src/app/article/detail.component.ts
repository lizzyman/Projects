/**
 * Created by Admin on 2017-05-17.
 */
import { Component } from '@angular/core';
import {Article} from "./article";
import {ArticleServcie} from "./article.service";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'detail',
  templateUrl: '../article/detail.component.html'
})
export class DetailComponet {
  article:Article = {
    _id: "",
    subject: "",
    content: "",
    writer: "",
    readCount: 0,
    originalname: "",
    filename: ""
  };

  constructor(private router:Router, private route:ActivatedRoute, private articleService:ArticleServcie){}

  deleteArticle() {
    this.route.params.subscribe(params => {
      let id = params['id'];
      console.log(id);
      this.articleService.deleteOneArticle(id).subscribe(response => {
        if (response) {
          this.router.navigate(['']);
        }
      });
    });
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      let id = params['id'];
      //console.log(id);
      this.articleService.getOneArticle(id).subscribe(article => this.article = article);
    });

  }
}
