import { Component } from '@angular/core';
import {UserConstant} from "./user/user.constant";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';

  getUser() {
    return UserConstant.user;
  }

  signOutUser() {
    this.getUser().id = '';
    this.getUser().name = '';
    this.getUser().password = '';
    this.getUser()._id = '';
  }

}
