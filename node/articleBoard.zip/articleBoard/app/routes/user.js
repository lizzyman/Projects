/**
 * Created by Admin on 2017-05-18.
 */
const route = require('express').Router();

const mongodb = require('../mongo/mongodb');

require('../mongo/mongodb');
const User = require('../model/user');

route.post("/signup", function (request, response) {
  let id = request.body.id;
  let password = request.body.password;
  let name = request.body.name;

  const user = new User({
    id: id,
    password: password,
    name: name
  });

  user.save();

  response.type('application/json');
  response.send({
    result: true
  });
});

route.post("/signin", function (request, response) {
  let id = request.body.id;
  let password = request.body.password;

  User.findOne({id: id, password: password}, function (err, user ) {
    response.type('application/json');

    if (err) {
      response.send({
        error: err
      });
    }
    else {
      if (id == user.id && password == user.password) {
        response.send({
          result: true,
          user: user
        });
      }
      else {
        response.send({
          result: false
        });
      }
    }

  });
});

exports.router = route;
