/**
 * Created by Admin on 2017-05-18.
 */

// 현재 서버에서 Router만 가져오기
const route = require('express').Router();

// MongoDB 연결
const mongodb = require('../mongo/mongodb');

// Model (VO) 가져오기
const Article = require('../model/article');
const upload = require('../util/upload');

route.post("/upload", upload.single('file'), function (request, response) {
  /*
   * File 처리
   */
  response.type("application/json");
  response.send({
    result: true,
    originalname: request.file.originalname,
    filename: request.file.filename
  });
  //});
});

route.post("/", function (request, response) {
  /*
   * Insert
   */
  let newArticle = new Article({
    subject: request.body.subject,
    content: request.body.content,
    writer: request.body.writer,
    readCount: 0,
    originalname: request.body.originalname,
    filename: request.body.filename
  });

  // file 정보 출력
  console.log("File : " + request.body.file);
  console.log(request.body.subject);

  //upload(request, response, function (error) {
    newArticle.save();

    response.type("application/json");
    response.send({
      result: true
    });
  //});
});

route.get("/:id", function (request, response) {
  // SELECT * FROM ARTICLE WHERE ID = ?

  let id = request.params.id;

  Article.findById(id, function (err, oneArticle) {
    response.type("application/json");
    response.send(oneArticle);
  });
});

route.delete("/:id", function (request, response) {
  /*
   * DELETE FROM ARTICLE WHERE ID = ?
   */
  let id = request.params.id;

  Article.findByIdAndRemove(id, function (err, result) { // result : delete하려는 대상 (나타나면 delete 성공)
    console.log(result);
    response.type("application/json");
    response.send({
      result: true
    });
  });
});

route.put("/:id", function (request, response) {
  /*
   * Update
   */
  let id = request.params.id;

  Article.findById(id, function (err, oneArticle) {
    oneArticle.subject = request.body.subject;
    oneArticle.content = request.body.content;
    oneArticle.writer = request.body.writer;

    oneArticle.save();

    response.type("application/json");
    response.send({
      result: true
    });
  });
});

exports.router = route;


