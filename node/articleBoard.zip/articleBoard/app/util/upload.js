/**
 * Created by Admin on 2017-05-19.
 */
/*
 * File Upload 관리
 */

const multer = require('multer');

const storage = multer.diskStorage({
  destination: function (request, file, cb) {
    cb(null, __dirname + '/../upload');
  }, // Upload가 되는 Directory
  filename: function (request, file, cb) {
    let datetimestamp = Date.now();

    console.log("DateTimeStamp : " + datetimestamp);

    let originalFileName = file.originalname;

    console.log("OriginalFileName : " + originalFileName);

    originalFileName = originalFileName.split('.');
    let originalName = originalFileName[0];
    let extName = originalFileName[originalFileName.length -1];

    cb(null, file.fieldName + '-' + datetimestamp + '-' + extName);
  }
});

const upload = multer({
  storage: storage
});

// 외부에서 upload 객체 사용 가능
module.exports = upload;
