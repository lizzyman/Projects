/**
 * Created by Admin on 2017-05-18.
 */
const mongoose = require('mongoose');

/***************************************************************/
/**************** Mongo Connect User Mongoose ******************/
/***************************************************************/

// function을 만들자마자 실행하는 코드

module.exports = function () {
  function mongoDbConnection() {
    mongoose.connect('mongodb://192.168.99.100:32768/ARTICLE', function (err) {
      console.log("Connecting MongoDB");
      if (err) {
        console.log(err);
      }
    });
  }

  function mongoDbDisconnected() {
    mongoose.connection.on('disconnected', mongoDbConnection);
  }

  mongoDbConnection();
  mongoDbDisconnected();
}();
